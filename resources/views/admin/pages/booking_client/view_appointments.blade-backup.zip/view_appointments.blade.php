@extends('admin.master')
@section('styles')

<link rel="stylesheet" href="{{asset('/files/bower_components/select2/css/select2.min.css')}}" />
<!-- Multi Select css -->
    <link rel="stylesheet" type="text/css" href="{{asset('/files/bower_components/bootstrap-multiselect/css/bootstrap-multiselect.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('/files/bower_components/multiselect/css/multi-select.css')}}" />
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="{{asset('/files/assets/css/style.css')}}">
@endsection
@section('page_header')
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-8">
                <div class="page-header-title">
                    <h5 class="m-b-10">View Appointments</h5>
                    <p class="m-b-0">Welcome to miyn dashboard</p>
                </div>
            </div>
            
        </div>
    </div>
</div>
@endsection
@section('main_content')

<div class="page-body">
   

<!-- Basic Form Inputs card start -->
    <div class="card">
        <div class="card-header">
        @if (session('success'))
          <div class="alert alert-success background-success">
                <strong>{{ session('success')}}</strong>
           </div>
        @endif
        @if (session('error'))
           <div class="alert alert-danger background-danger">
               {{ session('error')}}
           </div>
        @endif
            <div class="card-header">
                <h5>Appointments</h5>
            </div>
        </div>
        <div class="card-block">
            <div class="booking-content"> 
                <div class="booking-right">
                    <h3>{{ $booking->first_name }}</h3>
                    <h4>{{ $booking->service->name }}</h4>
                    <h3>{{ $date }}</h3>
                    <p>
                        
                        
                    @if($booking->confirmed == 0)
                        <h4 style="color:red;"> Pending</h4>
                    @else
                        <h4 style="color:green;"> Active</h4>
                    @endif

                    <p><img src="{{ asset('images/icon/user.png') }}"> with {{ $booking->first_name }}</p>

                    <p><img src="{{ asset('images/icon/telephone.svg') }}"> {{ $booking->phone }}</p>

                    <p><img src="{{ asset('images/icon/email.png') }}"> {{ $booking->email }}</p>

                    <p><img src="{{ asset('images/icon/message.png') }}"></p>
                    <p>Hi,
                        <br> {{ $booking->message }}.</p>
                    <p>Thanks</p>
                    <p></p>
                </div>
            </div>
            <a style="color:#fff;" class="btn btn-info btn-transparent btn-rounded" href="{{ route('view.accept.appointment', $booking->id) }}">ACCEPT</a>

            <a style="color:#fff;" class="btn btn-primary btn-transparent btn-rounded" href="{{ route('reschedule', $booking->id) }}">RE-SCHEDULE</a>
    
            <a style="color:#fff;" class="btn btn-danger btn-transparent btn-rounded" href="{{ url('booking-client-cancel/'.$booking->id.'/'.$booking->confirmed) }}">DELETE</a>
        </div>
    </div>
<!-- Basic Form Inputs card end -->

</div>

@endsection

@section('scripts')
<script type="text/javascript" src="{{asset('/files/bower_components/select2/js/select2.full.min.js')}}"></script>
<!-- Multiselect js -->
<script type="text/javascript" src="{{asset('/files/bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js')}}">
</script>
<script type="text/javascript" src="{{asset('/files/bower_components/multiselect/js/jquery.multi-select.js')}}"></script>
<script type="text/javascript" src="{{asset('/files/assets/js/jquery.quicksearch.js')}}"></script>
<!-- Custom js -->
<script type="text/javascript" src="{{asset('/files/assets/pages/advance-elements/select2-custom.js')}}"></script>

<!-- <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.css"> -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.43/css/bootstrap-datetimepicker.min.css"> 
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.43/css/bootstrap-datetimepicker-standalone.css"> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.43/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
    $(function () {
        //$('#datetimepicker').datetimepicker();
        $('#datetimepicker').datetimepicker({  
            minDate:new Date(),
            format: 'L',
        });
    });
</script>
    

@endsection